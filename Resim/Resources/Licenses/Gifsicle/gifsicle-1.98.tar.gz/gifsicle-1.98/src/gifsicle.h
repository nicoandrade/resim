/* gifsicle.h - Function declarations for gifsicle.
   Copyright (C) 1997-2025 Eddie Kohler, ekohler@gmail.com
   This file is part of gifsicle.

   Gifsicle is free software. It is distributed under the GNU Public License,
   version 2; you can copy, distribute, or alter it at will, as long
   as this notice is kept intact and this source code is made available. There
   is no warranty, express or implied. */

#ifndef GIFSICLE_H
#define GIFSICLE_H
#include <lcdfgif/gif.h>
#include <lcdf/clp.h>
#ifdef __GNUC__
#define NORETURN __attribute__ ((noreturn))
#define USED_ATTR __attribute__ ((used))
#else
#define NORETURN
#define USED_ATTR
#endif

typedef struct Gt_Frameset Gt_Frameset;
typedef struct Gt_Crop Gt_Crop;
typedef struct Gt_ColorTransform Gt_ColorTransform;

#if ENABLE_THREADS
#include <pthread.h>
extern pthread_mutex_t kd3_sort_lock;
#endif

typedef struct Gt_Frame {

  Gif_Stream *stream;
  Gif_Image *image;
  int use;

  Gif_Color transparent;        /* also background */
  int interlacing;
  int left;
  int top;

  Gt_Crop *crop;
  int left_offset;
  int top_offset;

  int delay;
  int disposal;

  Gt_Frameset *nest;
  int explode_by_name;

  int no_extensions_flag;
  int frame_no_extensions_flag;
  Gif_ExtensionList extensions;

  unsigned flip_horizontal: 1;
  unsigned flip_vertical: 1;
  unsigned info_flags: 3;
  unsigned position_is_offset: 1;
  unsigned rotation;

  const char *input_filename;

} Gt_Frame;


struct Gt_Frameset {
  int count;
  int cap;
  Gt_Frame *f;
};


struct Gt_Crop {
  int ready;
  int transparent_edges;
  int spec_x;
  int spec_y;
  int spec_w;
  int spec_h;
  int x;
  int y;
  int w;
  int h;
  int left_offset;
  int top_offset;
};


typedef void (*colormap_transform_func)(Gif_Colormap *, void *);

struct Gt_ColorTransform {
  Gt_ColorTransform *prev;
  Gt_ColorTransform *next;
  colormap_transform_func func;
  void *data;
};


typedef struct {

  const char *output_name;
  const char *active_output_name;

  int max_screen_width;
  int max_screen_height;

  int screen_mode;
  int screen_width;
  int screen_height;

  Gif_Color background;
  int loopcount;

  int colormap_size;
  Gif_Colormap* colormap_fixed;
  int colormap_fixed_exact;
  int colormap_algorithm;
  int colormap_needs_transparency;
  int dither_type;
  const uint8_t* dither_data;
  const char* dither_name;
  int colormap_gamma_type;
  double colormap_gamma;

  int optimizing;

  int scaling;
  int resize_width;
  int resize_height;
  int resize_flags;
  double scale_x;
  double scale_y;
  int scale_method;
  int scale_colors;

  int conserve_memory;

} Gt_OutputData;

#define GT_SCALING_NONE         0
#define GT_SCALING_RESIZE       1
#define GT_SCALING_SCALE        2

#define GT_RESIZE_FIT           1
#define GT_RESIZE_FIT_DOWN      2
#define GT_RESIZE_FIT_UP        4
#define GT_RESIZE_MIN_DIMEN     8

#define SCALE_METHOD_POINT      0
#define SCALE_METHOD_BOX        1
#define SCALE_METHOD_MIX        2
#define SCALE_METHOD_CATROM     3
#define SCALE_METHOD_LANCZOS2   4
#define SCALE_METHOD_LANCZOS3   5
#define SCALE_METHOD_MITCHELL   6

#define GT_OPT_MASK             0xFFFF
#define GT_OPT_KEEPEMPTY        0x10000
#define GT_OPT_KEEPCOLORMAP     0x20000


/*****
 * helper
 **/

static inline int
constrain(int low, int x, int high)
{
  return x < low ? low : (x < high ? x : high);
}


/*****
 * error & verbose
 **/

typedef struct Gt_MessageState {
  int verbosing;
  int verbose_pos;
  int error_count;
  uint8_t no_warnings;
  uint8_t no_ignore_errors;
  uint8_t warn_local_colormaps;
  uint8_t warn_local_colormaps_context;
  uint8_t irrelevant_background_context;
  uint8_t conflicting_background_context;
  uint8_t unoptimize_complexity_context;
  uint8_t redundant_option_context;
  int stopping;
} Gt_MessageState;

extern Gt_OutputData active_output_data;
extern Clp_Parser* clp;
extern const char* program_name;
extern Gt_MessageState gtmsgs;
extern Gif_CompressInfo gif_write_info;

extern Gif_Stream *input;
extern const char *input_name;

extern Gt_Frame def_frame;

extern int mode;
extern int nested_mode;

void fatal_error(const char* format, ...) NORETURN;
void stop_error(const char* format, ...);
void warning(int need_file, const char* format, ...);
void lwarning(const char* landmark, const char* format, ...);
void error(int need_file, const char* format, ...);
void lerror(const char* landmark, const char* format, ...);
void context_message(int need_file, const char* format, ...);
void clp_error_handler(Clp_Parser *clp, const char *clp_message);
void usage(Clp_Parser* clp);
void short_usage(Clp_Parser* clp);

void verbose_open(char, const char *);
void verbose_close(char);
void verbose_endline(void);

const char* debug_color_str(const Gif_Color* gfc);

#define EXIT_OK         0
#define EXIT_ERR        1
#define EXIT_USER_ERR   1

/*****
 * info &c
 **/
#define INFO_COLORMAPS  1
#define INFO_EXTENSIONS 2
#define INFO_SIZES      4
void stream_info(FILE *f, Gif_Stream *gfs, const char *filename, int flags);
void image_info(FILE *f, Gif_Stream *gfs, Gif_Image *gfi, int flags);

char *explode_filename(const char *filename, int number,
                       const char *name, int max_nimg);

/*****
 * merging images
 **/
void    unmark_colors(Gif_Colormap *);
void    unmark_colors_2(Gif_Colormap *);
void    mark_used_colors(Gif_Stream *gfs, Gif_Image *gfi, Gt_Crop *crop,
                         int compress_immediately);
int     find_color_index(Gif_Color *c, int nc, Gif_Color *);
int     merge_colormap_if_possible(Gif_Colormap *, Gif_Colormap *);

void    merge_stream(Gif_Stream *dest, Gif_Stream *src, int no_extensions_flag);
Gif_Image* merge_image(Gif_Stream* dest, Gif_Stream* src, Gif_Image* srci,
                       Gt_Frame* srcfr, int same_compressed_ok);

void    optimize_fragments(Gif_Stream*, const Gt_OutputData*, int huge_stream);

/*****
 * image/colormap transformations
 **/
Gif_Colormap *read_colormap_file(const char *, FILE *);
void    apply_color_transforms(Gt_ColorTransform *, Gif_Stream *);

typedef void (*color_transform_func)(Gif_Colormap *, void *);
Gt_ColorTransform *append_color_transform
        (Gt_ColorTransform *list, color_transform_func, void *);
Gt_ColorTransform *delete_color_transforms
        (Gt_ColorTransform *list, color_transform_func);

void    color_change_transformer(Gif_Colormap *, void *);
Gt_ColorTransform *append_color_change
        (Gt_ColorTransform *list, Gif_Color, Gif_Color);

void    pipe_color_transformer(Gif_Colormap *, void *);

void    combine_crop(Gt_Crop *dstcrop, const Gt_Crop *srccrop, const Gif_Image *gfi);
void    crop_image(Gif_Image* gfi, Gt_Frame* fr);

void    flip_image(Gif_Image* gfi, Gt_Frame* fr, int is_vert);
void    rotate_image(Gif_Image* gfi, Gt_Frame* fr, int rotation);
int     resize_dimensions(int* w, int* h, double new_width, double new_height,
                          int flags);
int     resize_stream(Gif_Stream* gfs, double new_width, double new_height,
                      int flags, int method, int scale_colors, int nthreads);

/*****
 * quantization
 **/
#define KC_GAMMA_SRGB                   0
#define KC_GAMMA_NUMERIC                1
#define KC_GAMMA_OKLAB                  2
void    kc_set_gamma(int type, double gamma);

#define COLORMAP_DIVERSITY              0
#define COLORMAP_BLEND_DIVERSITY        1
#define COLORMAP_MEDIAN_CUT             2

enum {
    dither_none = 0, dither_default, dither_floyd_steinberg,
    dither_ordered, dither_ordered_new, dither_atkinson
};
int     set_dither_type(Gt_OutputData* od, const char* name);
void    copy_dither(Gt_OutputData* dst, const Gt_OutputData* src);
void    colormap_stream(Gif_Stream*, Gif_Colormap*, Gt_OutputData*, int allow_shrink);

struct kchist;
Gif_Colormap* colormap_blend_diversity(struct kchist* kch, Gt_OutputData* od);
Gif_Colormap* colormap_flat_diversity(struct kchist* kch, Gt_OutputData* od);
Gif_Colormap* colormap_median_cut(struct kchist* kch, Gt_OutputData* od);


/*****
 * parsing stuff
 **/

typedef struct Gt_FrameSpec {
  int frame1;
  int frame2;
  const char* name;
} Gt_FrameSpec;

int             parse_frame_spec(Clp_Parser*, const char*, int, void*);
int             parse_dimensions(Clp_Parser*, const char*, int, void*);
int             parse_position(Clp_Parser*, const char*, int, void*);
int             parse_scale_factor(Clp_Parser*, const char*, int, void*);
double          strtod_decimal(const char*, char**);
int             parse_color(Clp_Parser*, const char*, int, void*);
int             parse_rectangle(Clp_Parser*, const char*, int, void*);
int             parse_two_colors(Clp_Parser*, const char*, int, void*);

void            input_stream(const char*);
void            input_done(void);
void            output_frames(void);

/*****
 * main
 **/
int     gifsicle_main(int argc, char *argv[]);
/* Free the memory and files held by gifsicle's state, so gifsicle_main can
   run again; gifsicle_main initializes everything else when it starts.
   gifsicle_main calls this before it returns. Calling it twice is safe. */
void    gifsicle_reset(void);

/*****
 * stuff with frames
 **/
#define         FRAME(fs, i)    ((fs)->f[i])

Gt_Frameset *   new_frameset(int initial_cap);
Gt_Frame*       add_frame(Gt_Frameset*, Gif_Stream*, Gif_Image*);
void            clear_def_frame_once_options(void);

Gif_Stream *    merge_frame_interval(Gt_Frameset*, int f1, int f2,
                                     Gt_OutputData*, int compress, int *huge);
void            merger_reset(void);
void            clear_frameset(Gt_Frameset*, int from);
void            blank_frameset(Gt_Frameset*, int from, int to, int delete_ob);

/*****
 * mode
 **/
#define BLANK_MODE      0
#define MERGING         1
#define BATCHING        2
#define EXPLODING       3
#define INFOING         4
#define DELETING        5
#define INSERTING       6
#define FRAME_SELECTION_MODE_MASK 0x1F


#define NOEXF_NAME      1
#define NOEXF_COMMENT   2
#define NOEXF_GENERIC   4
#define NOEXF_APP       8

static inline int extension_flag(Gif_Extension* ex) {
  if (ex->kind == GIF_EX_APP)
    return NOEXF_APP;
  else if (ex->kind == GIF_EX_NAME)
    return NOEXF_NAME;
  else if (ex->kind == GIF_EX_COMMENT)
    return NOEXF_COMMENT;
  return NOEXF_GENERIC;
}

#endif
