/* support.c - Support functions for gifsicle.
   Copyright (C) 1997-2025 Eddie Kohler, ekohler@gmail.com
   This file is part of gifsicle.

   Gifsicle is free software. It is distributed under the GNU Public License,
   version 2; you can copy, distribute, or alter it at will, as long
   as this notice is kept intact and this source code is made available. There
   is no warranty, express or implied. */

#include <config.h>
#include "gifsicle.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include <errno.h>
#include <math.h>
#include <limits.h>

const char *program_name = "gifsicle";


static void
verror(const char* landmark, int need_file,
       int seriousness, const char *fmt, va_list val)
{
    char pbuf[256], buf[BUFSIZ], xbuf[BUFSIZ];
    const char* xfmt;
    int n, i, p;
    size_t xi;

    if (!fmt || !*fmt)
        return;

    if (!landmark && need_file && active_output_data.active_output_name
        && mode != BLANK_MODE && mode != MERGING && nested_mode != MERGING)
        landmark = active_output_data.active_output_name;
    else if (!landmark)
        landmark = "";

    if (seriousness > 2)
        xfmt = "%s:%s%s fatal error: ";
    else if (seriousness == 1)
        xfmt = "%s:%s%s warning: ";
    else
        xfmt = "%s:%s%s ";
    snprintf(pbuf, sizeof(pbuf), xfmt, program_name, landmark, *landmark ? ":" : "");
    p = strlen(pbuf);

    Clp_vsnprintf(clp, buf, sizeof(buf), fmt, val);
    n = strlen(buf);
    if ((size_t) n + 1 < sizeof(buf) && (n == 0 || buf[n - 1] != '\n')) {
        buf[n++] = '\n';
        buf[n] = 0;
    }

    xi = 0;
    for (i = 0; i != n; ) {
        /* char* pos = (char*) memchr(&buf[i], '\n', n - i);
           int l = (pos ? &pos[1] - &buf[i] : n - i); */
        int l = n - i;
        int xd = snprintf(&xbuf[xi], sizeof(xbuf) - xi, "%.*s%.*s",
                          (int) p, pbuf, (int) l, &buf[i]);
        i += l;
        xi = (xi + xd > sizeof(xbuf) ? sizeof(xbuf) : xi + xd);
    }

    if (seriousness == 1 && gtmsgs.no_warnings)
        return;
    else if (seriousness > 1)
        gtmsgs.error_count++;

    verbose_endline();
    fwrite(xbuf, 1, xi, stderr);
}

void fatal_error(const char* format, ...) {
    va_list val;
    va_start(val, format);
    verror((const char*) 0, 0, 3, format, val);
    va_end(val);
    exit(EXIT_USER_ERR);
}

/* Report a fatal error without exiting. The caller should return promptly;
   gifsicle_main then stops and returns EXIT_USER_ERR. */
void stop_error(const char* format, ...) {
    va_list val;
    va_start(val, format);
    verror((const char*) 0, 0, 3, format, val);
    va_end(val);
    gtmsgs.stopping = 1;
}

void lerror(const char* landmark, const char* format, ...) {
    va_list val;
    va_start(val, format);
    verror(landmark, 2, 2, format, val);
    va_end(val);
}

void error(int need_file, const char* format, ...) {
    va_list val;
    va_start(val, format);
    verror((const char*) 0, need_file, 2, format, val);
    va_end(val);
}

void lwarning(const char* landmark, const char* format, ...) {
    va_list val;
    va_start(val, format);
    verror(landmark, 2, 1, format, val);
    va_end(val);
}

void warning(int need_file, const char* format, ...) {
    va_list val;
    va_start(val, format);
    verror((const char*) 0, need_file, 1, format, val);
    va_end(val);
}

void context_message(int need_file, const char* format, ...) {
    va_list val;
    va_start(val, format);
    verror((const char*) 0, need_file, 0, format, val);
    va_end(val);
}

void
clp_error_handler(Clp_Parser *clp, const char *message)
{
    (void) clp;
    verbose_endline();
    fputs(message, stderr);
}


void
short_usage(Clp_Parser* clp)
{
  fprintf(stderr, "Usage: %s [OPTION | FILE | FRAME]...\n\
Try %s%s --help%s for more information.\n",
          program_name, Clp_QuoteChar(clp, 0), program_name, Clp_QuoteChar(clp, 1));
}


void
usage(Clp_Parser* clp)
{
  const char* q0 = Clp_QuoteChar(clp, 0);
  const char* q1 = Clp_QuoteChar(clp, 1);
  printf("\
Gifsicle manipulates GIF images. Its most common uses include combining\n\
single images into animations, adding transparency, optimizing animations for\n\
space, and printing information about GIFs.\n\
\n\
Usage: %s [OPTION | FILE | FRAME]...\n\n", program_name);
  printf("\
Mode options (at most one, before any filenames):\n\
  -m, --merge                   Merge mode: combine inputs, write stdout\n\
  -b, --batch                   Batch mode: modify inputs, write back to\n\
                                same filenames\n\
  -e, --explode                 Explode mode: write N files for each input,\n\
                                one per frame, to %sinput.frame-number%s\n\
  -E, --explode-by-name         Explode mode, but write %sinput.name%s\n\n",
    q0, q1, q0, q1);
  printf("\
General options (also --no-OPTION for info and verbose):\n\
  -I, --info                    Print info about input GIFs\n\
  -I -I                         Print info to standard error; do not suppress\n\
                                normal output\n\
  --color-info, --cinfo         --info plus colormap details\n\
  --extension-info, --xinfo     --info plus extension details\n\
  --size-info, --sinfo          --info plus compression information\n\
  -V, --verbose                 Print progress (files read and written)\n");
  printf("\
  -h, --help                    Print this message and exit\n\
  --version                     Print version number and exit\n\
  -o, --output FILE             Write output to FILE\n\
  -w, --no-warnings             Don%st report warnings\n\
  --no-ignore-errors            Quit on very erroneous input GIFs\n\
  --max-screen WxH              Reject logical screens bigger than WxH\n\
                                [16384x16384]\n\
  --conserve-memory             Conserve memory at the expense of speed\n\
  --nextfile, --multifile       Support concatenated GIF files\n\n",
    q1);
  printf("\
Frame selections:               #num, #num1-num2, #num1-, #name\n\
\n\
Frame change options:\n\
  --delete FRAMES               Delete FRAMES from input\n\
  --insert-before FRAME GIFS    Insert GIFS before FRAMES in input\n\
  --append GIFS                 Append GIFS to input\n\
  --replace FRAMES GIFS         Replace FRAMES with GIFS in input\n\
  --done                        Done with frame changes\n\n");
  printf("\
Image options (also --no-OPTION and --same-OPTION):\n\
  -B, --background COL          Make COL the background color\n\
  --crop X,Y+WxH, --crop X,Y-X2,Y2\n\
                                Crop the image\n\
  --crop-transparency           Crop transparent borders off the image\n\
  --flip-horizontal, --flip-vertical\n\
                                Flip the image\n");
  printf("\
  -i, --interlace               Turn on interlacing\n\
  -S, --logical-screen WxH      Set logical screen to WxH\n\
  -p, --position X,Y            Set frame position to (X,Y)\n\
  --rotate-90, --rotate-180, --rotate-270, --no-rotate\n\
                                Rotate the image\n\
  -t, --transparent COL         Make COL transparent\n\n");
  printf("\
Extension options:\n\
  --app-extension N D           Add an app extension named N with data D\n\
  -c, --comment TEXT            Add a comment before the next frame\n\
  --extension N D           Add an extension number N with data D\n\
  -n, --name TEXT               Set next frame%ss name\n\
  --no-comments, --no-names, --no-extensions\n\
                                Remove comments (names, extensions) from input\n",
    q1);
  printf("\
Animation options (also --no-OPTION and --same-OPTION):\n\
  -d, --delay TIME              Set frame delay to TIME (in 1/100sec)\n\
  -D, --disposal METHOD         Set frame disposal to METHOD\n\
  -l, --loopcount[=N]           Set loop extension to N (default forever)\n\
  -O, --optimize[=LEVEL]        Optimize output GIFs\n\
  -U, --unoptimize              Unoptimize input GIFs\n");
#if ENABLE_THREADS
  printf("\
  -j, --threads[=THREADS]       Use multiple threads to improve speed\n");
#endif
  printf("\n\
Whole-GIF options (also --no-OPTION):\n\
  --careful                     Write larger GIFs that avoid bugs in other\n\
                                programs\n\
  --change-color COL1 COL2      Change COL1 to COL2 throughout\n\
  -k, --colors N                Reduce the number of colors to N\n\
  --color-method METHOD         Set method for choosing reduced colors\n\
  -f, --dither                  Dither image after changing colormap\n");
#if HAVE_POW
  printf("\
  --gamma G                     Set gamma for color reduction [2.2]\n");
#endif
  printf("\
  --lossy[=LOSSINESS]           Alter image colors to shrink output file size\n\
                                at the cost of artifacts and noise\n\
  --resize WxH                  Resize the output GIF to WxH\n\
  --scale XFACTOR[xYFACTOR]     Scale the output GIF by XFACTORxYFACTOR\n\
  --resize-width W              Resize to width W and proportional height\n\
  --resize-height H             Resize to height H and proportional width\n\
  --resize-fit WxH              Shrink to fit WxH, preserving aspect ratio\n\
  --resize-touch WxH            Resize to touch WxH, preserving aspect ratio\n\
  --resize-geometry GEOM        Resize to a geometry specification\n");
  printf("\
  --resize-method METHOD        Set resizing method\n\
  --resize-colors N             Resize can add new colors up to N\n\
  --transform-colormap CMD      Transform each output colormap by shell CMD\n\
  --use-colormap CMAP           Output GIF uses colors from CMAP, which can\n\
                                be %sweb%s, %sgray%s, %sbw%s, or a GIF file\n\
  --use-exact-colormap CMAP     Same, but use CMAP as is (not a subset)\n\
  --gray                        Same as --use-colormap gray\n\n",
    q1, q0, q1, q0, q1, q0);
  printf("\
Report bugs to <ekohler@gmail.com>.\n\
Too much information? Try %s%s --help | less%s.\n", q0, program_name, q1);
#ifdef GIF_UNGIF
  printf("\
This version of Gifsicle writes uncompressed GIFs, which can be far larger\n\
than compressed GIFs. See http://www.lcdf.org/gifsicle for more information.\n");
#endif
}


void
verbose_open(char open, const char *name)
{
  int l = strlen(name);
  if (gtmsgs.verbose_pos && gtmsgs.verbose_pos + 3 + l > 79) {
    fputc('\n', stderr);
    gtmsgs.verbose_pos = 0;
  }
  if (gtmsgs.verbose_pos) {
    fputc(' ', stderr);
    gtmsgs.verbose_pos++;
  }
  fputc(open, stderr);
  fputs(name, stderr);
  gtmsgs.verbose_pos += 1 + l;
}


void
verbose_close(char close)
{
  fputc(close, stderr);
  gtmsgs.verbose_pos++;
}


void
verbose_endline(void)
{
  if (gtmsgs.verbose_pos) {
    fputc('\n', stderr);
    fflush(stderr);
    gtmsgs.verbose_pos = 0;
  }
}


/*****
 * Info functions
 **/

const char* debug_color_str(const Gif_Color* gfc) {
    static int whichbuf = 0;
    static char buf[4][8];
    whichbuf = (whichbuf + 1) % 4;
    snprintf(buf[whichbuf], sizeof(buf[whichbuf]), "#%02X%02X%02X",
             gfc->gfc_red, gfc->gfc_green, gfc->gfc_blue);
    return buf[whichbuf];
}

static void
safe_puts(const char *s, uint32_t len, FILE *f)
{
  const char *last_safe = s;
  for (; len > 0; len--, s++)
    if (*s < ' ' || *s >= 0x7F || *s == '\\') {
      if (last_safe != s) {
        size_t n = s - last_safe;
        if (fwrite(last_safe, 1, n, f) != n)
          return;
      }
      last_safe = s + 1;
      switch (*s) {
       case '\a': fputs("\\a", f); break;
       case '\b': fputs("\\b", f); break;
       case '\f': fputs("\\f", f); break;
       case '\n': fputs("\\n", f); break;
       case '\r': fputs("\\r", f); break;
       case '\t': fputs("\\t", f); break;
       case '\v': fputs("\\v", f); break;
       case '\\': fputs("\\\\", f); break;
       case 0:    if (len > 1) fputs("\\000", f); break;
       default:   fprintf(f, "\\%03o", (unsigned char) *s); break;
      }
    }
  if (last_safe != s) {
    size_t n = s - last_safe;
    if (fwrite(last_safe, 1, n, f) != n)
      return;
  }
}


#define COLORMAP_COLS   4

static void
colormap_info(FILE *where, Gif_Colormap *gfcm, const char *prefix)
{
  int i, j;
  int nrows = ((gfcm->ncol - 1) / COLORMAP_COLS) + 1;

  for (j = 0; j < nrows; j++) {
    int which = j;
    fputs(prefix, where);
    for (i = 0; i < COLORMAP_COLS && which < gfcm->ncol; i++, which += nrows) {
      if (i) fputs("    ", where);
      fprintf(where, " %3d: #%02X%02X%02X", which, gfcm->col[which].gfc_red,
              gfcm->col[which].gfc_green, gfcm->col[which].gfc_blue);
    }
    fputc('\n', where);
  }
}


static void
comment_info(FILE *where, Gif_Extension *gfex, const char *prefix)
{
  fputs(prefix, where);
  safe_puts((const char*) gfex->data, gfex->length, where);
  fputc('\n', where);
}

static void
extension_info(FILE *where, Gif_Extension *gfex, const char *prefix,
               const char *hexprefix)
{
  uint8_t *data = gfex->data;
  uint32_t pos = 0;
  uint32_t len = gfex->length;

  fprintf(where, "%sextension ", prefix);
  if (gfex->kind == GIF_EX_APP) {
    fprintf(where, "app '");
    safe_puts(gfex->appname, GIF_EX_APPIDSIZE, where);
    fprintf(where, "'");
  } else {
    if (gfex->kind >= 32 && gfex->kind < 127)
      fprintf(where, "'%c' (0x%02X)", gfex->kind, gfex->kind);
    else
      fprintf(where, "0x%02X", gfex->kind);
  }
  if (gfex->packetized)
    fprintf(where, " packetized");
  fprintf(where, "\n");

  /* Now, hexl the data. */
  while (len > 0) {
    uint32_t row = 16;
    uint32_t i;
    if (row > len) row = len;
    fprintf(where, "%s%08x: ", hexprefix, pos);

    for (i = 0; i < row; i += 2) {
      if (i + 1 >= row)
        fprintf(where, "%02x   ", data[i]);
      else
        fprintf(where, "%02x%02x ", data[i], data[i+1]);
    }
    for (; i < 16; i += 2)
      fputs("     ", where);

    putc(' ', where);
    for (i = 0; i < row; i++, data++)
      putc((*data >= ' ' && *data < 127 ? *data : '.'), where);
    putc('\n', where);

    pos += row;
    len -= row;
  }
}


void
stream_info(FILE *where, Gif_Stream *gfs, const char *filename, int flags)
{
  Gif_Extension *gfex;
  int n;

  if (!gfs)
    return;

  verbose_endline();
  fprintf(where, "* %s %d image%s\n", (filename ? filename : "<stdin>"),
          gfs->nimages, gfs->nimages == 1 ? "" : "s");
  fprintf(where, "  logical screen %dx%d\n",
          gfs->screen_width, gfs->screen_height);

  if (gfs->global) {
    fprintf(where, "  global color table [%d]\n", gfs->global->ncol);
    if (flags & INFO_COLORMAPS)
      colormap_info(where, gfs->global, "  |");
    fprintf(where, "  background %d\n", gfs->background);
  }

  if (gfs->loopcount == 0)
    fprintf(where, "  loop forever\n");
  else if (gfs->loopcount > 0)
    fprintf(where, "  loop count %u\n", (unsigned)gfs->loopcount);

  n = 0;
  for (gfex = gfs->end_extensions.head; gfex; gfex = gfex->next) {
    if (gfex->kind == GIF_EX_COMMENT)
      comment_info(where, gfex, "  end comment ");
    else {
      if (flags & INFO_EXTENSIONS)
        extension_info(where, gfex, "  end ", "    ");
      else
        ++n;
    }
  }
  if (n)
    fprintf(where, "  end extensions %d\n", n);
}


static const char *disposal_names[] = {
  "none", "asis", "background", "previous", "4", "5", "6", "7"
};

void
image_info(FILE *where, Gif_Stream *gfs, Gif_Image *gfi, int flags)
{
  Gif_Extension* gfex;
  int num, nex;
  if (!gfs || !gfi)
    return;
  num = Gif_ImageNumber(gfs, gfi);

  verbose_endline();
  fprintf(where, "  + image #%d ", num);
  if (Gif_ImageName(gfi))
    fprintf(where, "#%s ", Gif_ImageName(gfi));

  fprintf(where, "%dx%d", gfi->width, gfi->height);
  if (gfi->left || gfi->top)
    fprintf(where, " at %d,%d", gfi->left, gfi->top);

  if (gfi->interlace)
    fprintf(where, " interlaced");

  if (gfi->transparent >= 0)
    fprintf(where, " transparent %d", gfi->transparent);

  fprintf(where, "\n");

  if ((flags & INFO_SIZES) && gfi->compressed)
    fprintf(where, "    compressed size %u\n", gfi->compressed_len);

  nex = 0;
  for (gfex = gfi->extensions.head; gfex; gfex = gfex->next) {
    if (gfex->kind == GIF_EX_COMMENT)
      comment_info(where, gfex, "    comment ");
    else if (gfex->kind != GIF_EX_NAME) {
      if (flags & INFO_EXTENSIONS)
        extension_info(where, gfex, "    ", "      ");
      else
        ++nex;
    }
  }
  if (nex)
    fprintf(where, "    extensions %d\n", nex);

  if (gfi->local) {
    fprintf(where, "    local color table [%d]\n", gfi->local->ncol);
    if (flags & INFO_COLORMAPS)
      colormap_info(where, gfi->local, "    |");
  }

  if (gfi->disposal || gfi->delay) {
    fprintf(where, "   ");
    if (gfi->disposal)
      fprintf(where, " disposal %s", disposal_names[gfi->disposal]);
    if (gfi->delay)
      fprintf(where, " delay %d.%02ds",
              gfi->delay / 100, gfi->delay % 100);
    fprintf(where, "\n");
  }
}


/* Return the output filename for an exploded frame. The caller must free
   the result with Gif_DeleteArray. */
char *
explode_filename(const char *filename, int number, const char *name, int max_nimages)
{
  char *s;
  int l = strlen(filename);
  l += name ? strlen(name) : 10;

  s = Gif_NewArray(char, l + 3);
  if (name)
    snprintf(s, l + 3, "%s.%s", filename, name);
  else if (max_nimages <= 1000)
    snprintf(s, l + 3, "%s.%03d", filename, number);
  else {
    int digits;
    unsigned j;
    unsigned max = (max_nimages < 0 ? 0 : max_nimages);
    for (digits = 4, j = 10000; max > j; digits++)
      j *= 10;
    snprintf(s, l + 3, "%s.%0*d", filename, digits, number);
  }

  return s;
}


/*****
 * parsing functions
 **/

/* Parse a frame number, clamping it to +/-INT_MAX so out-of-range numbers
   are reported as out of range rather than wrapping. */
static int
strtol_frame(char *s, char **end)
{
  long v = strtol(s, end, 10);
  return v > INT_MAX ? INT_MAX : (v < -INT_MAX ? -INT_MAX : (int) v);
}

int
parse_frame_spec(Clp_Parser *clp, const char *arg, int complain, void *thunk)
{
  char *c;
  Gt_FrameSpec* gtfspec = (Gt_FrameSpec*) clp->val.cs;
  (void)thunk;

  gtfspec->frame1 = 0;
  gtfspec->frame2 = -1;
  gtfspec->name = 0;

  if (!input && !input_name)
    input_stream(0);
  if (!input)
    return 0;

  if (arg[0] != '#') {
    if (complain)
      Clp_OptionError(clp, "frame specifications must start with #");
    return 0;
  }
  arg++;
  c = (char *)arg;

  /* Get a number range (#x, #x-y, or #x-). First, read x. */
  if (isdigit((unsigned char) c[0]))
    gtfspec->frame1 = gtfspec->frame2 = strtol_frame(c, &c);
  else if (c[0] == '-' && isdigit((unsigned char) c[1]))
    gtfspec->frame1 = gtfspec->frame2 = Gif_ImageCount(input) + strtol_frame(c, &c);

  /* Then, if the next character is a dash, read y. Be careful to prevent
     #- from being interpreted as a frame range. */
  if (c[0] == '-' && (gtfspec->frame2 >= 0 || c[1] != 0)) {
    c++;
    if (isdigit((unsigned char) c[0]))
      gtfspec->frame2 = strtol_frame(c, &c);
    else if (c[0] == '-' && isdigit((unsigned char) c[1]))
      gtfspec->frame2 = Gif_ImageCount(input) + strtol_frame(c, &c);
    else
      gtfspec->frame2 = Gif_ImageCount(input) - 1;
  }

  /* It really was a number range (and not a frame name)
     only if c is now at the end of the argument. */
  if (c[0] != 0) {
    Gif_Image *gfi = Gif_GetNamedImage(input, arg);
    if (gfi) {
      gtfspec->name = (const char*) arg;
      gtfspec->frame1 = gtfspec->frame2 = Gif_ImageNumber(input, gfi);
      return 1;
    }
    if (complain < 0)    /* -1 is special value meaning 'don't complain
                                   about frame NAMES, but do complain about
                                   frame numbers.' */
      return -97;               /* Return -97 on bad frame name. */
    else if (complain)
      Clp_OptionError(clp, "no frame named %<#%s%>", arg);
    return 0;
  }
  if (gtfspec->frame1 >= 0
      && gtfspec->frame1 < Gif_ImageCount(input)
      && gtfspec->frame2 >= 0
      && gtfspec->frame2 < Gif_ImageCount(input))
    return 1;
  if (complain)
    Clp_OptionError(clp, "frame %<#%s%> out of range, image has %d frames", arg, Gif_ImageCount(input));
  return 0;
}

/* Parse a decimal coordinate or dimension. Values outside +/-65535, the GIF
   limit, leave *end pointing at `s` so the caller reports a parse error. */
static int
strtol_coord(const char *s, char **end)
{
  long v = strtol(s, end, 10);
  if (v < -65535 || v > 65535) {
    *end = (char *) s;
    return 0;
  }
  return (int) v;
}

int
parse_dimensions(Clp_Parser *clp, const char *arg, int complain, void *thunk)
{
  char *val;
  (void)thunk;

  if (*arg == '_' && arg[1] == 'x') {
    clp->val.is[0] = 0;
    val = (char *)(arg + 1);
  } else
    clp->val.is[0] = strtol_coord(arg, &val);
  if (*val == 'x') {
    if (val[1] == '_' && val[2] == 0) {
      clp->val.is[1] = 0;
      val = val + 2;
    } else
      clp->val.is[1] = strtol_coord(val + 1, &val);
    if (*val == 0)
      return 1;
  }

  if (complain)
    Clp_OptionError(clp, "invalid dimensions %<%s%> (want WxH)", arg);
  return 0;
}

int
parse_position(Clp_Parser *clp, const char *arg, int complain, void *thunk)
{
  char *val;
  (void)thunk;

  clp->val.is[0] = strtol_coord(arg, &val);
  if (*val == ',') {
    clp->val.is[1] = strtol_coord(val + 1, &val);
    if (*val == 0)
      return 1;
  }

  if (complain)
    Clp_OptionError(clp, "invalid position %<%s%> (want 'X,Y')", arg);
  return 0;
}

/* Like strtod, but accept only decimal numbers. strtod also accepts hex
   floats, "inf", and "nan"; we parse pairs like "0x1" as 0 then "x1". */
double strtod_decimal(const char* arg, char** endptr) {
    const char* p = arg + (*arg == '+' || *arg == '-');
    if (!isdigit((unsigned char) *p)
        && !(*p == '.' && isdigit((unsigned char) p[1]))) {
        *endptr = (char*) arg;
        return 0;
    } else if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X')) {
        *endptr = (char*) p + 1;
        return 0;
    } else
        return strtod(arg, endptr);
}

static double strtod_fraction(const char* arg, char** endptr) {
    char* val, *val2;
    double d = strtod_decimal(arg, &val);
    if (arg != val && *val == '/') {
        double denom = strtod_decimal(val + 1, &val2);
        if (val2 != val + 1 && denom) {
            d /= denom;
            val = val2;
        }
    }
    if (endptr)
        *endptr = val;
    return d;
}

int
parse_scale_factor(Clp_Parser *clp, const char *arg, int complain, void *thunk)
{
  char *val;
  (void)thunk;

  clp->val.ds[0] = strtod_fraction(arg, &val);
  if (*val == 'x')
    clp->val.ds[1] = strtod_fraction(val + 1, &val);
  else
    clp->val.ds[1] = clp->val.ds[0];

  /* reject NaN and infinity */
  if (*val == 0
      && isfinite(clp->val.ds[0])
      && isfinite(clp->val.ds[1]))
    return 1;

  if (complain)
    Clp_OptionError(clp, "invalid scale factor %<%s%> (want XxY)", arg);
  return 0;
}

int
parse_rectangle(Clp_Parser *clp, const char *arg, int complain, void *thunk)
{
  const char *input_arg = arg;
  char *val;
  int x = strtol_coord(arg, &val);
  (void)thunk;

  if (*val == ',') {
    int y = strtol_coord(val + 1, &val);
    if (*val == '-' && parse_position(clp, val + 1, 0, 0)) {
      int position_x = clp->val.is[0], position_y = clp->val.is[1];
      if (x >= 0 && y >= 0
          && (position_x <= 0 || x < position_x)
          && (position_y <= 0 || y < position_y)) {
        /* 18.May.2008: Found it unintuitive that X,Y-0,0 acted like X,Y+-Xx-Y.
           Therefore changed it so that X,Y-0,0 acts like X,Y+0,0, and similar
           for negative dimensions.  Probably safe to change this behavior
           since only X,Y+0,0 was documented. */
        clp->val.is[0] = x;
        clp->val.is[1] = y;
        clp->val.is[2] = position_x <= 0 ? -position_x : position_x - x;
        clp->val.is[3] = position_y <= 0 ? -position_y : position_y - y;
        return 1;
      }
    } else if (*val == '+' && parse_dimensions(clp, val + 1, 0, 0)) {
      clp->val.is[2] = clp->val.is[0];
      clp->val.is[3] = clp->val.is[1];
      clp->val.is[0] = x;
      clp->val.is[1] = y;
      return 1;
    }
  } else if (*val == 'x') {
    clp->val.is[2] = x;
    clp->val.is[3] = strtol_coord(val + 1, &val);
    if (*val == 0) {
      clp->val.is[0] = clp->val.is[1] = 0;
      return 1;
    }
  }

  if (complain)
    Clp_OptionError(clp, "invalid rectangle %<%s%> (want X1,Y1-X2,Y2 or X1,Y1+WxH", input_arg);
  return 0;
}

static int
xvalue(char c)
{
  switch (c) {
   case '0': case '1': case '2': case '3': case '4':
   case '5': case '6': case '7': case '8': case '9':
    return c - '0';
   case 'A': case 'B': case 'C': case 'D': case 'E': case 'F':
    return c - 'A' + 10;
   case 'a': case 'b': case 'c': case 'd': case 'e': case 'f':
    return c - 'a' + 10;
   default:
    return -1;
  }
}

static int
parse_hex_color_channel(const char *s, int ndigits)
{
  int val1 = xvalue(s[0]);
  if (val1 < 0) return -1;
  if (ndigits == 1)
    return val1 * 16 + val1;
  else {
    int val2 = xvalue(s[1]);
    if (val2 < 0) return -1;
    return val1 * 16 + val2;
  }
}

int
parse_color(Clp_Parser *clp, const char *arg, int complain, void *thunk)
{
  const char *input_arg = arg;
  char *str;
  int red, green, blue;
  Gif_Color* pcolor = (Gif_Color*) clp->val.cs;
  (void)thunk;

  if (*arg == '#') {
    int len = strlen(++arg);
    if (len == 0 || len % 3 != 0
        || (int)strspn(arg, "0123456789ABCDEFabcdef") != len) {
      if (complain)
        Clp_OptionError(clp, "invalid color %<%s%> (want #RGB or #RRGGBB)",
                        input_arg);
      return 0;
    }

    len /= 3;
    red   = parse_hex_color_channel(&arg[ 0 * len ], len);
    green = parse_hex_color_channel(&arg[ 1 * len ], len);
    blue  = parse_hex_color_channel(&arg[ 2 * len ], len);
    goto gotrgb;

  } else if (!isdigit((unsigned char) *arg))
    goto error;

  red = strtol(arg, &str, 10);
  if (*str == 0) {
    if (red < 0 || red > 255)
      goto error;
    pcolor->haspixel = 1;
    pcolor->pixel = red;
    return 1;

  } else if (*str != ',' && *str != '/')
    goto error;

  if (*++str == 0) goto error;
  green = strtol(str, &str, 10);
  if (*str != ',' && *str != '/') goto error;

  if (*++str == 0) goto error;
  blue = strtol(str, &str, 10);
  if (*str != 0) goto error;

 gotrgb:
  if (red < 0 || green < 0 || blue < 0
      || red > 255 || green > 255 || blue > 255)
    goto error;
  pcolor->gfc_red = red;
  pcolor->gfc_green = green;
  pcolor->gfc_blue = blue;
  pcolor->haspixel = 0;
  return 1;

 error:
  if (complain)
    Clp_OptionError(clp, "invalid color %<%s%>", input_arg);
  return 0;
}

int
parse_two_colors(Clp_Parser *clp, const char *arg, int complain, void *thunk)
{
  Gif_Color old_color;
  Gif_Color* pcolor = (Gif_Color*) clp->val.cs;
  if (parse_color(clp, arg, complain, thunk) <= 0)
    return 0;
  old_color = *pcolor;

  arg = Clp_Shift(clp, 0);
  if (!arg) {
    if (complain)
      Clp_OptionError(clp, "%<%O%> takes two color arguments");
    return 0;
  }

  if (parse_color(clp, arg, complain, thunk) <= 0)
    return 0;

  pcolor[1] = pcolor[0];
  pcolor[0] = old_color;
  return 1;
}


/*****
 * reading a file as a colormap
 **/

static Gif_Colormap *
read_text_colormap(FILE *f, const char *name)
{
  char buf[BUFSIZ];
  Gif_Colormap *cm = Gif_NewFullColormap(0, 256);
  Gif_Color *col = cm->col;
  int ncol = 0;
  unsigned red, green, blue;
  float fred, fgreen, fblue;

  while (fgets(buf, BUFSIZ, f)) {

    if (sscanf(buf, "%g %g %g", &fred, &fgreen, &fblue) == 3) {
      if (fred < 0) fred = 0;
      if (fgreen < 0) fgreen = 0;
      if (fblue < 0) fblue = 0;
      red = (unsigned)(fred + .5);
      green = (unsigned)(fgreen + .5);
      blue = (unsigned)(fblue + .5);
      goto found;

    } else if (buf[0] == '#'
               && strspn(buf + 1, "0123456789abcdefABCDEF") == 3
               && (!buf[4] || isspace((unsigned char) buf[4]))) {
      sscanf(buf + 1, "%1x%1x%1x", &red, &green, &blue);
      red += red << 4;
      green += green << 4;
      blue += blue << 4;
      goto found;

    } else if (buf[0] == '#'
               && strspn(buf + 1, "0123456789abcdefABCDEF") == 6
               && (!buf[7] || isspace((unsigned char) buf[7]))) {
      sscanf(buf + 1, "%2x%2x%2x", &red, &green, &blue);
     found:
      if (red > 255) red = 255;
      if (green > 255) green = 255;
      if (blue > 255) blue = 255;
      if (ncol >= 256) {
        lerror(name, "maximum 256 colors allowed in colormap");
        break;
      } else {
        col[ncol].gfc_red = red;
        col[ncol].gfc_green = green;
        col[ncol].gfc_blue = blue;
        ncol++;
      }
    }

    /* handle too-long lines gracefully */
    if (strchr(buf, '\n') == 0) {
      int c;
      for (c = getc(f); c != '\n' && c != EOF; c = getc(f))
        ;
    }
  }

  if (ncol == 0) {
    lerror(name, "file not in colormap format");
    Gif_DeleteColormap(cm);
    return 0;
  } else {
    cm->ncol = ncol;
    return cm;
  }
}

static void
no_gifread_error(Gif_Stream* gfs, Gif_Image* gfi,
                 int is_error, const char *message) {
    (void) gfs, (void) gfi, (void) is_error, (void) message;
}

Gif_Colormap *
read_colormap_file(const char *name, FILE *f)
{
  Gif_Colormap *cm = 0;
  int c;
  int my_file = 0;

  if (name && strcmp(name, "-") == 0)
    name = 0;
  if (!f) {
    my_file = 1;
    if (!name)
      f = stdin;
    else
      f = fopen(name, "rb");
    if (!f) {
      lerror(name, "%s", strerror(errno));
      return 0;
    }
  }

  name = name ? name : "<stdin>";
  if (gtmsgs.verbosing) verbose_open('<', name);

  c = getc(f);
  ungetc(c, f);
  if (c == 'G') {
    Gif_Stream *gfs = Gif_FullReadFile(f, GIF_READ_COMPRESSED, 0, no_gifread_error);
    if (!gfs)
      lerror(name, "file not in GIF format");
    else if (!gfs->global
             && (gfs->nimages == 0 || !gfs->images[0]->local))
      lerror(name, "can%,t use as palette (no global color table)");
    else {
      if (gfs->errors)
        lwarning(name, "there were errors reading this GIF");
      cm = Gif_CopyColormap(gfs->global ? gfs->global : gfs->images[0]->local);
    }

    Gif_DeleteStream(gfs);
  } else
    cm = read_text_colormap(f, name);

  if (my_file) fclose(f);
  if (gtmsgs.verbosing) verbose_close('>');
  return cm;
}


/*****
 * Frame stuff
 **/


Gt_Frameset *
new_frameset(int initial_cap)
{
  Gt_Frameset *fs = Gif_New(Gt_Frameset);
  if (initial_cap < 0) initial_cap = 0;
  fs->cap = initial_cap;
  fs->count = 0;
  fs->f = Gif_NewArray(Gt_Frame, initial_cap);
  return fs;
}


void
clear_def_frame_once_options(void)
{
  /* Get rid of next-frame-only options.

     This causes problems with frame selection. In the command 'gifsicle
     -nblah f.gif', the name should be applied to frame 0 of f.gif. This will
     happen automatically when f.gif is read, since all of its frames will be
     added when it is input. After frame 0, the name in def_frame will be
     cleared.

     Now, 'gifsicle -nblah f.gif #1' should apply the name to frame 1 of
     f.gif. But once f.gif is input, its frames are added, and the name
     component of def_frame is cleared!! So when #1 comes around it's gone!

     We handle this in gifsicle.c using the _change fields. */

  Gif_DeleteExtensions(&def_frame.extensions);
  def_frame.frame_no_extensions_flag = 0;
}


Gt_Frame *
add_frame(Gt_Frameset *fset, Gif_Stream *gfs, Gif_Image *gfi)
{
    int number = fset->count++;
    while (number >= fset->cap) {
        fset->cap *= 2;
        Gif_ReArray(fset->f, Gt_Frame, fset->cap);
    }

  /* Mark the stream and the image both */
  gfs->refcount++;
  gfi->refcount++;
  fset->f[number] = def_frame;
  fset->f[number].stream = gfs;
  fset->f[number].image = gfi;
  fset->f[number].extensions.head = fset->f[number].extensions.tail = 0;
  if (!Gif_CopyExtensions(&fset->f[number].extensions, &def_frame.extensions))
    fatal_error("out of memory");

  clear_def_frame_once_options();

  return &fset->f[number];
}


static Gt_Frame **merger = 0;
static int nmerger = 0;
static int mergercap = 0;

void
merger_reset(void)
{
  Gif_DeleteArray(merger);
  merger = 0;
  nmerger = mergercap = 0;
}

static void
merger_add(Gt_Frame *fp)
{
  while (nmerger >= mergercap)
    if (mergercap) {
      mergercap *= 2;
      Gif_ReArray(merger, Gt_Frame *, mergercap);
    } else {
      mergercap = 16;
      merger = Gif_NewArray(Gt_Frame *, mergercap);
    }
  merger[ nmerger++ ] = fp;
}


static void
merger_flatten(Gt_Frameset *fset, int f1, int f2)
{
  int i;
  assert(f1 >= 0 && f2 < fset->count);
  for (i = f1; i <= f2; i++) {
    Gt_Frameset *nest = FRAME(fset, i).nest;

    if (nest && nest->count > 0) {
      if (FRAME(fset, i).use < 0 && nest->count == 1) {
        /* use < 0 means use the frame's delay, disposal and name (if not
           explicitly overridden), but not the frame itself. */
        if (FRAME(nest, 0).delay < 0)
          FRAME(nest, 0).delay = FRAME(fset, i).image->delay;
        if (FRAME(nest, 0).disposal < 0)
          FRAME(nest, 0).disposal = FRAME(fset, i).image->disposal;
        if (!(FRAME(nest, 0).no_extensions_flag & NOEXF_NAME)
            && !Gif_ExtensionListName(&FRAME(nest, 0).extensions)) {
          const char* identifier = Gif_ImageName(FRAME(fset, i).image);
          Gif_Extension* ngfex;
          if (identifier
              && (ngfex = Gif_NewExtensionData(GIF_EX_NAME, 0, identifier, strlen(identifier)))) {
            Gif_AppendExtension(&FRAME(nest, 0).extensions, ngfex);
            FRAME(nest, 0).frame_no_extensions_flag |= NOEXF_NAME;
          }
        }
      }
      merger_flatten(nest, 0, nest->count - 1);
    }

    if (FRAME(fset, i).use > 0)
      merger_add(&FRAME(fset, i));
  }
}


static int
find_color_or_error(Gif_Color *color, Gif_Stream *gfs, Gif_Image *gfi,
                    const char *color_context)
{
  Gif_Colormap *gfcm = gfs->global;
  int index;
  if (gfi && gfi->local)
    gfcm = gfi->local;

  if (color->haspixel == 2) {   /* have pixel value, not color */
    if (!gfcm || color->pixel < (uint32_t)gfcm->ncol)
      return color->pixel;
    else {
      if (color_context)
          lwarning(gfs->landmark, "%s color out of range", color_context);
      return -1;
    }
  }

  index = gfcm ? Gif_FindColor(gfcm, color) : -1;
  if (index < 0 && color_context)
    lwarning(gfs->landmark, "%s color not in colormap", color_context);
  return index;
}

static void
set_background(Gif_Stream *gfs, Gt_OutputData *output_data)
{
    Gif_Color background;
    int i, conflict, want_transparent;
    Gif_Image *gfi;

    /* Check for user-specified background. */
    /* If they specified the number, silently cooperate. */
    if (output_data->background.haspixel == 2) {
        gfs->background = output_data->background.pixel;
        return;
    }

    /* Otherwise, if they specified a color, search for it. */
    if (output_data->background.haspixel) {
        if (gfs->images[0]->transparent >= 0) {
            if (!gtmsgs.irrelevant_background_context) {
                warning(1, "irrelevant background color\n"
                        "  (The background will appear transparent because"
                        "  the first image contains transparency.)");
                gtmsgs.irrelevant_background_context = 1;
            } else
                warning(1, "irrelevant background color");
        }
        background = output_data->background;
        goto search;
    }

    /* If we get here, user doesn't care about background. */
    /* Search for required background colors. */
    conflict = want_transparent = background.haspixel = 0;
    for (i = 0; i < nmerger; i++) {
        gfi = gfs->images[i];
        if (gfi->disposal == GIF_DISPOSAL_BACKGROUND
            || (i == 0 && (gfi->left != 0 || gfi->top != 0
                           || gfi->width != gfs->screen_width
                           || gfi->height != gfs->screen_height))) {
            /* transparent.haspixel set in merge_frame_interval */
            int original_bg_transparent = (merger[i]->transparent.haspixel == 2);
            if ((original_bg_transparent && background.haspixel)
                || (!original_bg_transparent && want_transparent))
                conflict = 2;
            else if (original_bg_transparent)
                want_transparent = 1;
            else if (merger[i]->transparent.haspixel) {
                if (background.haspixel
                    && !GIF_COLOREQ(&background, &merger[i]->transparent))
                    conflict = 1;
                else {
                    background = merger[i]->transparent;
                    background.haspixel = 1;
                }
            }
        }
    }

    /* Report conflicts. */
    if (conflict || (want_transparent && gfs->images[0]->transparent < 0)) {
        if (!gtmsgs.conflicting_background_context) {
            warning(1, "input images have conflicting background colors\n"
                    "  (This means some animation frames may appear incorrect.)");
            gtmsgs.conflicting_background_context = 1;
        } else
            warning(1, "input images have conflicting background colors");
    }

    /* If no important background color, bag. */
    if (!background.haspixel) {
        gfs->background = 0;
        return;
    }

  search:
    i = find_color_or_error(&background, gfs, 0, "background");
    gfs->background = (i >= 0 ? i : 0);
}



static void
handle_flip_and_rotate(Gif_Image* desti, Gt_Frame* fr)
{
    int sw = fr->stream->screen_width, sh = fr->stream->screen_height;
    desti->left += fr->left_offset;
    desti->top += fr->top_offset;

    /* Flips and rotations are relative to the logical screen. Parts of
       frames outside the screen are invisible and have no transformed
       position, so drop them; a frame entirely outside the screen becomes a
       transparent 1x1 placeholder inside the screen. */
    Gif_ClipImage(desti, 0, 0, sw, sh);
    if ((desti->width == 0 || desti->height == 0) && sw > 0 && sh > 0) {
        desti->left = desti->left < sw ? desti->left : sw - 1;
        desti->top = desti->top < sh ? desti->top : sh - 1;
        Gif_MakeImageEmpty(desti);
    }

    if (fr->flip_horizontal)
        flip_image(desti, fr, 0);
    if (fr->flip_vertical)
        flip_image(desti, fr, 1);

    if (fr->rotation == 1)
        rotate_image(desti, fr, 1);
    else if (fr->rotation == 2) {
        flip_image(desti, fr, 0);
        flip_image(desti, fr, 1);
    } else if (fr->rotation == 3)
        rotate_image(desti, fr, 3);

    /* a placeholder for a frame outside an empty crop can land before the
       crop origin; don't let its position wrap */
    desti->left = desti->left > fr->left_offset ? desti->left - fr->left_offset : 0;
    desti->top = desti->top > fr->top_offset ? desti->top - fr->top_offset : 0;
}

static void
analyze_crop(int nmerger, Gt_Crop* crop, int compress_immediately)
{
  int i, l = 0x7FFFFFFF, r = 0, t = 0x7FFFFFFF, b = 0;
  Gif_Stream* cropped_gfs = 0;

  /* find cropped stream */
  for (i = 0; i < nmerger; i++)
      if (merger[i]->crop == crop)
          cropped_gfs = merger[i]->stream;

  /* find border of frames */
  for (i = 0; i < nmerger; i++)
    if (merger[i]->crop == crop) {
      Gt_Frame *fr = merger[i];
      int ll, tt, rr, bb;
      if (!fr->position_is_offset) {
        /* only consider the part of the frame on the logical screen */
        int sw = fr->stream->screen_width, sh = fr->stream->screen_height;
        ll = fr->image->left;
        tt = fr->image->top;
        rr = constrain(ll, fr->image->left + fr->image->width, sw);
        bb = constrain(tt, fr->image->top + fr->image->height, sh);
        if (ll >= rr || tt >= bb)
          continue;
      } else {
        ll = tt = 0;
        rr = fr->stream->screen_width;
        bb = fr->stream->screen_height;
      }
      if (ll < l)
        l = ll;
      if (tt < t)
        t = tt;
      if (rr > r)
        r = rr;
      if (bb > b)
        b = bb;
    }

  if (t > b)
    /* total crop */
    l = r = t = b = 0;

  crop->x = crop->spec_x + l;
  crop->y = crop->spec_y + t;
  crop->w = crop->spec_w + (crop->spec_w <= 0 ? r - crop->x : 0);
  crop->h = crop->spec_h + (crop->spec_h <= 0 ? b - crop->y : 0);
  crop->left_offset = crop->x;
  crop->top_offset = crop->y;
  if (crop->x < 0 || crop->y < 0 || crop->w <= 0 || crop->h <= 0
      || crop->x + crop->w > r || crop->y + crop->h > b) {
      lerror(cropped_gfs ? cropped_gfs->landmark : (const char*) 0,
             "cropping dimensions don%,t fit image");
      crop->ready = 2;
      /* clip the crop to the image so later computations stay sane */
      if (crop->w < 0)
        crop->w = 0;
      if (crop->h < 0)
        crop->h = 0;
      crop->w = constrain(l, crop->x + crop->w, r);
      crop->x = constrain(l, crop->x, r);
      crop->w = crop->w > crop->x ? crop->w - crop->x : 0;
      crop->h = constrain(t, crop->y + crop->h, b);
      crop->y = constrain(t, crop->y, b);
      crop->h = crop->h > crop->y ? crop->h - crop->y : 0;
      crop->left_offset = crop->x;
      crop->top_offset = crop->y;
  } else
      crop->ready = 1;

  /* Remove transparent edges. */
  if (crop->transparent_edges && crop->ready == 1) {
    int have_l = crop->x, have_t = crop->y,
      have_r = crop->x + crop->w, have_b = crop->y + crop->h;
    l = t = 0x7FFFFFFF, r = b = 0;

    for (i = 0;
         i < nmerger && (l > have_l || t > have_t || r < have_r || b < have_b);
         ++i) {
      if (merger[i]->crop == crop) {
        Gt_Frame *fr = merger[i];
        Gif_Image *srci = fr->image;
        int ll = constrain(have_l, srci->left, have_r),
          tt = constrain(have_t, srci->top, have_b),
          rr = constrain(have_l, srci->left + srci->width, have_r),
          bb = constrain(have_t, srci->top + srci->height, have_b);

        if (srci->transparent >= 0) {
          int x, y;
          uint8_t **img;
          Gif_UncompressImage(fr->stream, srci);
          img = srci->img;

          /* Move top edge down over transparency */
          while (tt < bb && tt < t) {
            uint8_t *data = img[tt - srci->top];
            for (x = 0; x < srci->width; ++x)
              if (data[x] != srci->transparent)
                goto found_top;
            ++tt;
          }

        found_top:
          /* Move bottom edge up over transparency */
          while (bb > tt + 1 && bb > b) {
            uint8_t *data = img[bb - 1 - srci->top];
            for (x = 0; x < srci->width; ++x)
              if (data[x] != srci->transparent)
                goto found_bottom;
            --bb;
          }

        found_bottom:
          if (tt < bb) {
            /* Move left edge right over transparency */
            while (ll < rr && ll < l) {
              for (y = tt - srci->top; y < bb - srci->top; ++y)
                if (img[y][ll - srci->left] != srci->transparent)
                  goto found_left;
              ++ll;
            }

          found_left:
            /* Move right edge left over transparency */
            while (rr > ll + 1 && rr > r) {
              for (y = tt - srci->top; y < bb - srci->top; ++y)
                if (img[y][rr - 1 - srci->left] != srci->transparent)
                  goto found_right;
              --rr;
            }
          }

        found_right:
          if (compress_immediately > 0 && srci->compressed)
            Gif_ReleaseUncompressedImage(srci);
        }

        /* a frame outside the crop horizontally contributes nothing */
        if (tt < bb && ll < rr) {
          if (ll < l)
            l = ll;
          if (tt < t)
            t = tt;
          if (rr > r)
            r = rr;
          if (bb > b)
            b = bb;
        }
      }
    }

    if (t >= b || l >= r) {
      /* everything is transparent; keep a 1x1 crop, since later code
         assumes a nonempty crop */
      crop->w = crop->h = 1;
    } else {
      crop->x = l;
      crop->y = t;
      crop->w = r - l;
      crop->h = b - t;
      crop->left_offset = crop->x;
      crop->top_offset = crop->y;
    }
  }
}


static inline int
apply_frame_transparent(Gif_Image *gfi, Gt_Frame *fr)
{
    int old_transparent = gfi->transparent;
    if (fr->transparent.haspixel == 255)
        gfi->transparent = -1;
    else if (fr->transparent.haspixel) {
        gfi->transparent =
            find_color_or_error(&fr->transparent, fr->stream, gfi,
                                "transparent");
        if (gfi->transparent < 0)
            fr->transparent.haspixel = 0;
    }
    return old_transparent;
}

static void mark_used_background_color(Gt_Frame* fr) {
    Gif_Stream* gfs = fr->stream;
    Gif_Image* gfi = fr->image;
    if ((fr->transparent.haspixel != 0
         ? fr->transparent.haspixel != 255
         : gfi->transparent < 0)
        && ((fr->disposal >= 0
             ? fr->disposal
             : gfi->disposal) == GIF_DISPOSAL_BACKGROUND
            || gfi->left != 0
            || gfi->top != 0
            || gfi->width != gfs->screen_width
            || gfi->height != gfs->screen_height)
        && gfs->global
        && gfs->background < gfs->global->ncol)
        gfs->global->col[gfs->background].haspixel |= 1;
}

Gif_Stream *
merge_frame_interval(Gt_Frameset *fset, int f1, int f2,
                     Gt_OutputData *output_data, int compress_immediately,
                     int *huge_stream)
{
  Gif_Stream *dest = Gif_NewStream();
  Gif_Colormap *global = Gif_NewFullColormap(256, 256);
  Gif_Image *crop_copy = 0;
  int i, same_compressed_ok, all_same_compressed_ok;

  global->ncol = 0;
  dest->global = global;
  if (output_data->active_output_name)
      dest->landmark = Gif_CopyString(output_data->active_output_name);
  /* 11/23/98 A new stream's screen size is 0x0; we'll use the max of the
     merged-together streams' screen sizes by default (in merge_stream()) */

  if (f2 < 0)
      f2 = fset->count - 1;
  nmerger = 0;
  merger_flatten(fset, f1, f2);
  if (nmerger == 0) {
    error(1, "empty output GIF not written");
    goto error;
  }

  /* decide whether stream is huge */
  {
    size_t s;
    for (i = s = 0; i < nmerger; i++)
        s += (((unsigned) merger[i]->image->width
               * (unsigned) merger[i]->image->height) / 1024) + 1;
    *huge_stream = (s > 200 * 1024); /* 200 MB */
    if (*huge_stream && !compress_immediately) {
      warning(1, "huge GIF, conserving memory (processing may take a while)");
      compress_immediately = 1;
    }
  }

  /* merge stream-specific info and clear colormaps */
  for (i = 0; i < nmerger; i++)
    merger[i]->stream->user_flags = 1;
  for (i = 0; i < nmerger; i++) {
    if (merger[i]->stream->user_flags) {
      Gif_Stream *src = merger[i]->stream;
      Gif_CalculateScreenSize(src, 0);
      /* merge_stream() unmarks the global colormap */
      merge_stream(dest, src, merger[i]->no_extensions_flag);
      src->user_flags = 0;
    }
    if (merger[i]->image->local)
      unmark_colors_2(merger[i]->image->local);
  }

  /* is it ok to save the same compressed image? This is true only if we
     will recompress later from scratch. */
  /* 13.Aug.2002 - Can't save the same compressed image if we crop, so turn
     off all_same_compressed_ok below ('analyze crops'). Reported by Tom
     Schumm <phong@phong.org>. */
  if (output_data->colormap_size > 0
      || output_data->colormap_fixed
      || (output_data->optimizing & GT_OPT_MASK)
      || output_data->scaling > 0)
    all_same_compressed_ok = 1;
  else
    all_same_compressed_ok = 0;

  /* analyze crops */
  for (i = 0; i < nmerger; i++) {
    if (merger[i]->crop)
      merger[i]->crop->ready = all_same_compressed_ok = 0;
  }
  for (i = 0; i < nmerger; i++) {
    if (merger[i]->crop && !merger[i]->crop->ready)
      analyze_crop(nmerger, merger[i]->crop, compress_immediately);
  }

  /* mark used colors */
  for (i = 0; i < nmerger; ++i) {
      int old_transp = apply_frame_transparent(merger[i]->image, merger[i]);
      mark_used_colors(merger[i]->stream, merger[i]->image, merger[i]->crop,
                       compress_immediately);
      merger[i]->image->transparent = old_transp;
      mark_used_background_color(merger[i]);
  }

  /* copy stream-wide information from output_data */
  if (output_data->loopcount > -2)
    dest->loopcount = output_data->loopcount;
  dest->screen_width = dest->screen_height = 0;

  /** ACTUALLY MERGE FRAMES INTO THE NEW STREAM **/
  for (i = 0; i < nmerger; i++) {
    Gt_Frame *fr = merger[i];
    Gif_Image *srci;
    Gif_Image *desti;
    int old_transp;

    /* Make a copy of the image and crop it if we're cropping */
    fr->left_offset = fr->top_offset = 0;
    if (fr->crop) {
      srci = crop_copy = Gif_CopyImage(fr->image);
      Gif_UncompressImage(fr->stream, srci);
      crop_image(srci, fr);
    } else {
      srci = fr->image;
      Gif_UncompressImage(fr->stream, srci);
    }

    old_transp = apply_frame_transparent(srci, fr);

    /* Is it ok to use the old image's compressed version? */
    /* 11.Feb.2003 -- It is NOT ok to use the old image's compressed version
       if you are going to flip or rotate the image. Crash reported by Dan
       Lasley <Dan_Lasley@hilton.com>. */
    same_compressed_ok = all_same_compressed_ok;
    if ((fr->interlacing >= 0 && fr->interlacing != srci->interlace)
        || fr->flip_horizontal || fr->flip_vertical || fr->rotation)
      same_compressed_ok = 0;

    desti = merge_image(dest, fr->stream, srci, fr, same_compressed_ok);

    srci->transparent = old_transp; /* restore real transparent value */

    /* Flipping and rotating */
    if (fr->flip_horizontal || fr->flip_vertical || fr->rotation) {
      handle_flip_and_rotate(desti, fr);
    }

    /* Extensions */
    if (fr->extensions.head) {
      if (desti->extensions.tail) {
        desti->extensions.tail->next = fr->extensions.head;
      } else {
        desti->extensions.head = fr->extensions.head;
      }
      desti->extensions.tail = fr->extensions.tail;
      fr->extensions.head = fr->extensions.tail = 0;
    }

    if (fr->interlacing >= 0) {
      desti->interlace = fr->interlacing;
    }
    if (fr->left >= 0) {
      int left = fr->left + (fr->position_is_offset ? desti->left : 0);
      if (left + desti->width > 65535) {
        error(1, "left position %d out of range", left);
        goto error;
      }
      desti->left = left;
    }
    if (fr->top >= 0) {
      int top = fr->top + (fr->position_is_offset ? desti->top : 0);
      if (top + desti->height > 65535) {
        error(1, "top position %d out of range", top);
        goto error;
      }
      desti->top = top;
    }

    if (fr->delay >= 0) {
      desti->delay = fr->delay;
    }
    if (fr->disposal >= 0) {
      desti->disposal = fr->disposal;
    }

    /* logical screen */
    if (output_data->screen_mode <= 0) {
      int w, h;
      if (output_data->screen_mode < 0
          || fr->crop
          || ((fr->left >= 0 || fr->top >= 0) && !fr->position_is_offset)) {
        w = desti->left + desti->width;
        h = desti->top + desti->height;
      } else {
        if (fr->rotation == 1 || fr->rotation == 3) {
          w = fr->stream->screen_height;
          h = fr->stream->screen_width;
        } else {
          w = fr->stream->screen_width;
          h = fr->stream->screen_height;
        }
        if (fr->left >= 0) {
          w += fr->left;
        }
        if (fr->top >= 0) {
          h += fr->top;
        }
      }
      w = w > 65535 ? 65535 : w;
      h = h > 65535 ? 65535 : h;
      if (w > dest->screen_width) {
        dest->screen_width = w;
      }
      if (h > dest->screen_height) {
        dest->screen_height = h;
      }
    }

    /* compress immediately if possible to save on memory */
    if (desti->img) {
      if (compress_immediately > 0) {
        Gif_FullCompressImage(dest, desti, &gif_write_info);
        Gif_ReleaseUncompressedImage(desti);
      } else if (desti->compressed)
        Gif_ReleaseCompressedImage(desti);
    } else if (compress_immediately <= 0) {
      Gif_UncompressImage(dest, desti);
      Gif_ReleaseCompressedImage(desti);
    }

    /* 6/17/02 store information about image's background */
    if (fr->stream->images[0]->transparent >= 0) {
        fr->transparent.haspixel = 2;
    } else if (fr->stream->global
               && fr->stream->background < fr->stream->global->ncol) {
        fr->transparent = fr->stream->global->col[fr->stream->background];
        fr->transparent.haspixel = 1;
    } else {
        fr->transparent.haspixel = 0;
    }

    /* Destroy the copied, cropped image if necessary */
    Gif_DeleteImage(crop_copy);
    crop_copy = 0;

    /* if we can, delete the image's data right now to save memory */
    srci = fr->image;
    assert(srci->refcount > 1);
    if (--srci->refcount == 1) {
      /* only 1 reference ==> the reference is from the input stream itself */
      Gif_ReleaseUncompressedImage(srci);
      Gif_ReleaseCompressedImage(srci);
    }
    fr->image = 0;

    /* 5/26/98 Destroy the stream now to help with memory. Assumes that
       all frames are added with add_frame() which properly increments the
       stream's refcount. Set field to 0 so we don't redelete */
    Gif_DeleteStream(fr->stream);
    fr->stream = 0;
  }
  /** END MERGE LOOP **/

  if (output_data->screen_mode == 1) {
    dest->screen_width = output_data->screen_width;
    dest->screen_height = output_data->screen_height;
  }

  /* Check the screen size limit. Later steps grow the screen to fit the
     first image, so check the grown screen. An explicit --logical-screen
     is allowed, but growth beyond it is checked. */
  {
    int max_w = output_data->max_screen_width;
    int max_h = output_data->max_screen_height;
    if (output_data->screen_mode == 1) {
      max_w = output_data->screen_width > max_w ? output_data->screen_width : max_w;
      max_h = output_data->screen_height > max_h ? output_data->screen_height : max_h;
    }
    Gif_CalculateScreenSize(dest, 0);
    if (dest->screen_width > max_w || dest->screen_height > max_h) {
      if (output_data->screen_mode == 1)
        error(1, "output screen size %dx%d too large\n"
              "  (Frames extend past the logical screen, and the limit is %dx%d.\n"
              "  Change it with %<--max-screen%>.)",
              dest->screen_width, dest->screen_height, max_w, max_h);
      else
        error(1, "output screen size %dx%d too large\n"
              "  (The limit is %dx%d. Change it with %<--max-screen%>, or\n"
              "  set the screen size with %<--logical-screen%>.)",
              dest->screen_width, dest->screen_height, max_w, max_h);
      goto error;
    }
    if (output_data->screen_mode == 1
        && (dest->screen_width > output_data->screen_width
            || dest->screen_height > output_data->screen_height)) {
      warning(1, "logical screen grown from %dx%d to %dx%d to fit first frame",
              output_data->screen_width, output_data->screen_height,
              dest->screen_width, dest->screen_height);
    }
  }

  /* Find the background color in the colormap, or add it if we can */
  set_background(dest, output_data);

  /* The global colormap might be empty even given images that use it, if
     those images are entirely transparent. Since absent global colormaps
     are surprising, assign a black-and-white colormap */
  if (dest->global->ncol == 0) {
      for (i = 0; i != dest->nimages; ++i)
          if (!dest->images[i]->local) {
              GIF_SETCOLOR(&dest->global->col[0], 0, 0, 0);
              GIF_SETCOLOR(&dest->global->col[1], 255, 255, 255);
              dest->global->ncol = 2;
              break;
          }
  }

  return dest;

 error:
  /* Frames not yet merged keep their references; blank_frameset()
     releases them. */
  Gif_DeleteImage(crop_copy);
  Gif_DeleteStream(dest);
  return 0;
}


void
blank_frameset(Gt_Frameset *fset, int f1, int f2, int delete_object)
{
  int i;
  if (delete_object) f1 = 0, f2 = -1;
  if (f2 < 0) f2 = fset->count - 1;
  for (i = f1; i <= f2; i++) {
    /* We may have deleted stream and image earlier to save on memory; see
       above in merge_frame_interval(); but if we didn't, do it now. */
    if (FRAME(fset, i).image && FRAME(fset, i).image->refcount > 1)
      FRAME(fset, i).image->refcount--;
    Gif_DeleteStream(FRAME(fset, i).stream);
    Gif_DeleteExtensions(&FRAME(fset, i).extensions);
    if (FRAME(fset, i).nest)
      blank_frameset(FRAME(fset, i).nest, 0, 0, 1);
  }
  if (delete_object) {
    Gif_DeleteArray(fset->f);
    Gif_Delete(fset);
  }
}


void
clear_frameset(Gt_Frameset *fset, int f1)
{
  blank_frameset(fset, f1, -1, 0);
  fset->count = f1;
}
